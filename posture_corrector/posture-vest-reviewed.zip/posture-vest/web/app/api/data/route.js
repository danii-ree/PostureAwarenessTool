import { update, authed, deny, json } from '@/lib/store';
export async function DELETE(req) {
  if (!authed(req)) return deny();
  await update(db => { db.hours = {}; }, true);
  return json({ ok: true });
}
